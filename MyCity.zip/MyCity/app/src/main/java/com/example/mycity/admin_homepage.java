package com.example.mycity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class admin_homepage extends AppCompatActivity {
    Button admin_complaint_view,admin_complaint_forward,admin_citizen_lists;
    database myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_homepage);
        admin_complaint_view = findViewById(R.id.admin_complaint_view);
        admin_complaint_forward=findViewById(R.id.admin_complaint_forward);
        admin_citizen_lists=findViewById(R.id.admin_citizen_list);
        myDb = new database(this);
//        deleteComplaint();
        complaintView();
        forwardComplaint();
        userView();

    }

    private void userView() {
        admin_citizen_lists.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(admin_homepage.this, admin_citizen_list.class);
                startActivity(intent);
            }
        });
    }

//    private void deleteComplaint() {
//        String updated_regno = getIntent().getStringExtra("regno");
//        Integer res = myDb.deleteData(updated_regno);
//        if (res > 0){
//            Toast.makeText(admin_homepage.this, "Data Deleted", Toast.LENGTH_LONG).show();
//        complaintView();
//    }
//        else
//            Toast.makeText(admin_homepage.this,"Data not Deleted",Toast.LENGTH_LONG).show();
//    }

    private void forwardComplaint() {
        admin_complaint_forward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(admin_homepage.this,admin_department_forward.class);
                startActivity(intent);
            }
        });

    }

    public void complaintView() {
       // String updated_regno = getIntent().getStringExtra("regno");


    admin_complaint_view.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
//                Intent nextpage=new Intent(admin_homepage.this,admin_department_forward.class);
//                startActivity(nextpage);
            Cursor res = myDb.getAllComplaints();
            if (res.getCount() == 0) {
                Toast.makeText(admin_homepage.this, "No record found", Toast.LENGTH_SHORT).show();

                return;
            }
            StringBuffer buffer = new StringBuffer();

                while (res != null && res.moveToNext()) {

                    buffer.append("REG NO:" + res.getString(0) + "\n");
                    buffer.append("COMPLAINER:" + res.getString(1) + "\n");
                    buffer.append("COMPLAINT NAME:" + res.getString(2) + "\n");
                    buffer.append("PHONE NO:" + res.getString(3) + "\n");
                    buffer.append("DETAILS:" + res.getString(5) + "\n");
                }


                showMessage("COMPLAINTS", buffer.toString());





        }

    });
}
    public void showMessage(String title, String message) {

        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();

    }


}